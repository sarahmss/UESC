% Definindo as cores
colors = lines(10); 

% Definindo a função de transferência
num = 52.8 * [1 22.67 194]; 
den = [1 14.16 149 223.83]; 
FT = tf(num, den)
FT_zpk = zpk(FT)
polos = pole(FT_zpk)
zeros_ft = zero(FT_zpk)

% Definindo o vetor de tempo
t = 0:0.01:40; 

% Criando a figura para resposta senoidal
figure;
hold on;

% Inicialização do vetor de frequências
w = linspace(1, 50, 8); % Frequências de 1 a 50 rad/s, 8 valores


% Loop para diferentes frequências
for n = 1:length(w)
    omega = w(n);
    u_sin = sin(omega * t); % Sinal de entrada senoidal
    
    % Simular a resposta ao sinal senoidal
    [y_senoidal, tOut_senoidal] = lsim(FT, u_sin, t);
    
    % Criar subplot e plotar
    subplot(4, 2, n);
    plot(tOut_senoidal, y_senoidal, 'Color', colors(n,:), 'DisplayName', 'Resposta Senoidal');
    hold on;
    plot(tOut_senoidal, u_sin, 'Color', colors(n,:), 'LineStyle', '--', 'DisplayName', 'Entrada Senoidal');
    title(['Resposta e Entrada Senoidal para \omega = ', num2str(omega)]);
    xlabel('Tempo (s)');
    ylabel('Amplitude');
    legend;
    grid on;
end
hold off;
%% Ensaio para obter diagrama de Bode
% Inicialização do vetor de frequências
w = 0.0:0.1:1000; % Frequências de 0 a 100 rad/s, com passo 0.01

% Inicializar vetores de amplitude e fase
amplitude_y = zeros(length(w), 1);
amplitude_u = zeros(length(w), 1);
phase = zeros(length(w), 1);


min_rp = 300;
max_rp = 1000;
% Loop para diferentes frequências
for n = 2:length(w)

    omega = w(n); % Frequência atual
    u_sin = sin(omega * t); % Sinal de entrada senoidal

    % Simular a resposta ao sinal senoidal
    y_senoidal = lsim(FT, u_sin, t);

    % Cálculo da amplitude
    amplitude_y(n) = max(y_senoidal(min_rp:max_rp)); % Amplitude do sinal de saída
    amplitude_u(n) = max(u_sin(min_rp:max_rp)); % Amplitude do sinal de saída
    
    loc_u = find(u_sin(min_rp:max_rp) == amplitude_u(n));
    loc_y = find(y_senoidal(min_rp:max_rp) == amplitude_y(n));

    if ~isempty(loc_u) && ~isempty(loc_y)
        t1 =  t(min_rp + loc_u);
        t2 = t(min_rp + loc_y);
        
        % Cálculo do atraso de fase (em radianos)
        phase(n) = (t2 - t1)*omega*180/pi;
    end

end

% Conversão de amplitude para dB
amplitude_db = 20 * log10(amplitude_y);

% Gráficos do diagrama de Bode
figure;
subplot(2, 1, 1);
semilogx(w, amplitude_db); % Amplitude em dB
xlabel('Frequência (rad/s)');
ylabel('Amplitude (dB)');
title('Diagrama de Bode - Amplitude');
grid on; % Habilitar grade

subplot(2, 1, 2);
semilogx(w, phase); % Fase em graus
xlabel('Frequência (rad/s)');
ylabel('Fase (graus)');
title('Diagrama de Bode - Fase');
grid on; % Habilitar grade
%%
% Obter o diagrama de Bode
figure;
bode(FT);
grid on;
title('Diagrama de Bode');

