colors = lines(10);

% Definindo a função de transferência original
num_original = 52.8 * [1 22.67 194]; 
den_original = [1 14.16 149 223.83]; 
FTOriginal = tf(num_original, den_original);
FTOriginalZpk = zpk(FTOriginal)

% Definindo a função de transferência aproximada via Diagrama de Bode
num_aprox_bode = conv(12.68, conv([1 23.4], [1 23.4])); 
den_aprox_bode = conv([1 1.4], conv([1 10.5], [1 10.5])); 
FTAprox_bode = tf(num_aprox_bode, den_aprox_bode)
FTAproxZpk_bode = zpk(FTAprox_bode)

% Definindo a função de transferência aproximada via resposta ao degrau
num_aprox_deg = 85.6528; 
den_aprox_deg = [1 1.88]; 
FTAprox_deg = tf(num_aprox_deg, den_aprox_deg);
FTAproxZpk_deg = zpk(FTAprox_deg)

% Preparando os LGRs
FTs = {FTOriginal, FTAprox_bode, FTAprox_deg};
titles = {'Original', 'Aproximado por Diagrama de Bode', 'Aproximado por Resposta ao Degrau'};

%% Plotando os LGRs na mesma figura
figure;
hold on;
for i = 1:length(FTs)
    subplot(3, 1, i); % Um subplot por valor de K
    rlocus(FTs{i});
    title(['Lgr ', titles{i}]);
    grid on;
end
legend(titles);
hold off;
