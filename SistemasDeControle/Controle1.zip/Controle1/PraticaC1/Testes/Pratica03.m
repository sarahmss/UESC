% Definindo as cores
colors = lines(10); 

% Definindo a função de transferência
num = 52.8 * [1 22.67 194]; 
den = [1 14.16 149 223.83]; 
FT = tf(num, den)
FT_zpk = zpk(FT)
polos = pole(FT_zpk)
zeros_ft = zero(FT_zpk)

%%

% Definindo o vetor de tempo para o ensaio
t = 0:0.0008:80-0.0008;

% Inicialização do vetor de frequências para o ensaio
w = 0.0:0.1:100; % Frequências de 0.1 a 100 rad/s

% Inicializar vetores de amplitude e fase para o ensaio
amplitude_y = zeros(length(w), 1);
amplitude_u = zeros(length(w), 1);
phase = zeros(length(w), 1);

max_rp = length(t);
min_rp_y = 3/4 * max_rp;
min_rp_u = 1/10 * max_rp;

N = length(w);
% Loop para diferentes frequências
for n = 2:N
    omega = w(n); % Frequência atual
    u_sin = sin(omega * t); % Sinal de entrada senoidal

    % Simular a resposta ao sinal senoidal
    y_senoidal = lsim(FT, u_sin, t);

    % Cálculo da amplitude (sinal de saída e entrada)
    [amplitude_y(n), loc_y] = max(y_senoidal(min_rp_y:max_rp)); 
    loc_y = min_rp_y + loc_y - 1;
    t1 = t(loc_y);
    
    for x = round(min_rp_u):1:max_rp 
        if (u_sin(x-1) > u_sin(x-2) && u_sin(x-1) > u_sin(x) && t(x-1) < t1)
            amplitude_u(n) = u_sin(x-1);
            loc_u = x-1;
        end
    end
    

    % Cálculo do atraso de fase (se picos são detectados)
    delay = t(loc_u) - t1;  % Diferença temporal entre os picos
    phase(n) = delay * omega * (180/pi); % Atraso de fase em graus

    fprintf('Progresso: %.2f%%\n', (n/N)*100);
end

% Conversão de amplitude para dB
amplitude_db = 20 * log10(amplitude_y);

%% Plotar sobreposição dos resultados experimentais e de referência

% Gráfico do diagrama de Bode (ensaio experimental)
figure;
subplot(2, 1, 1);
semilogx(w, amplitude_db, 'Color', colors(1,:), 'LineWidth', 1.5); % Amplitude do ensaio
hold on;
xlabel('Frequência (rad/s)');
ylabel('Amplitude (dB)');
title('Diagrama de Bode - Amplitude');
grid on; % Habilitar grade

subplot(2, 1, 2);
semilogx(w, phase, 'Color', colors(2,:), 'LineWidth', 1.5); % Fase do ensaio
hold on;
xlabel('Frequência (rad/s)');
ylabel('Fase (graus)');
title('Diagrama de Bode - Fase');
grid on; % Habilitar grade

%% Obter o diagrama de Bode da função de transferência (referência)

[mag, phase_ref, omega_ref] = bode(FT, w);
mag = squeeze(mag); % Converter para vetor
phase_ref = squeeze(phase_ref); % Converter para vetor
omega_ref = squeeze(omega_ref); % Frequências correspondentes

% Conversão da magnitude para dB
mag_db = 20 * log10(mag);

% Plotar amplitude da referência
subplot(2, 1, 1);
semilogx(omega_ref, mag_db, 'Color', colors(3,:), 'LineStyle', '--', 'LineWidth', 1.5); % Amplitude de referência
legend('Experimental', 'Referência');

% Plotar fase da referência
subplot(2, 1, 2);
semilogx(omega_ref, phase_ref, 'Color', colors(4,:), 'LineStyle', '--', 'LineWidth', 1.5); % Fase de referência
legend('Experimental', 'Referência');


%% 
t = 0:0.01:40; 
figure;
hold on;
[y,tOut] = step(FT);
plot(tOut, y);   
title(['Resposta ao degrau em função da variação de tal. caso: ', num2str(c)]);
xlabel('Parte Real');
ylabel('Parte Imaginária');
legend; 
grid on;
hold off;