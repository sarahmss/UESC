%% Funções de Transferência
colors = lines(10);

% Definindo a função de transferência original
num_original = 52.8 * [1 22.67 194]; 
den_original = [1 14.16 149 223.83]; 
FTOriginal = tf(num_original, den_original);
FTOriginalZpk = zpk(FTOriginal);

% Definindo a função de transferência aproximada via Diagrama de Bode
num_aprox_bode = conv(12.68, conv([1 23.4], [1 23.4])); 
den_aprox_bode = conv([1 1.4], conv([1 10.5], [1 10.5])); 
FTAprox_bode = tf(num_aprox_bode, den_aprox_bode);
FTAproxZpk_bode = zpk(FTAprox_bode);

% Definindo a função de transferência aproximada via resposta ao degrau
num_aprox_deg = 85.6528; 
den_aprox_deg = [1 1.88]; 
FTAprox_deg = tf(num_aprox_deg, den_aprox_deg);
FTAproxZpk_deg = zpk(FTAprox_deg);

%% Controlador por ajuste de ganho e cálculo da malha fechada

% Lista com as funções de transferência
FTs = {FTOriginal, FTAprox_bode, FTAprox_deg};
titles = {'Original', 'Aproximado por Diagrama de Bode', 'Aproximado por Resposta ao Degrau'};
t = linspace(0, 1.4, 500); % Gera 500 pontos de tempo entre 0 e 1.2 segundos

% Faixa de ganho para o controlador
ganhos = [0.1, 0.25, 0.5, 0.75, 1, 2, 4, 8];

% Loop para calcular e exibir as funções de transferência em malha fechada
figure;
for k = 1:length(ganhos)
    K = ganhos(k);
    subplot(4, 2, k);
    hold on;
    
    for i = 1:length(FTs)
        FT = FTs{i};
        FT_cl = feedback(K * FT, 1); % Função de transferência em malha fechada
        
        % Resposta ao degrau
        [y, tOut] = step(FT_cl, t); % Simular a resposta ao degrau do sistema em malha fechada
        
        % Plotando cada função de transferência na mesma figura
        plot(tOut, y, 'DisplayName', titles{i}, 'Color', colors(i, :), 'LineWidth', 1.5);
    end
    
    % Configurações do gráfico
    xlabel('Tempo (s)');
    ylabel('Amplitude');
    legend('show');
    grid on;
    title(num2str(K));
    hold off;
end
