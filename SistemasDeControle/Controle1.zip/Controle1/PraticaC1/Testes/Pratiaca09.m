% Definindo a função de transferência original
num_original = 52.8 * [1 22.67 194]; 
den_original = [1 14.16 149 223.83]; 
FTOriginal = tf(num_original, den_original);

t = linspace(0, 0.3, 500);

% Parâmetros do sistema
L = 0.01; % Valor fixo para L
C = 0.6239 - L; 
A = 45;  
R = A / C; 

% Valores para ajuste do ganho (variável "a")
a_values = 1:2:12;

% Figura para plotagem
figure;

for i = 1:length(a_values)
    a = a_values(i);
    subplot(3, 2, i);
    
    % Controlador Proporcional-Integral-Derivativo (PID)
    Kp_pid = 1.2 / (R * L);
    Ki_pid = a * 0.6 / (R * L^2);
    Kd_pid = 0.6 / R;
    
    s = tf('s'); 
    Cs_pid = Kp_pid + Ki_pid/s + Kd_pid*s;
    % Sistema controlado por PID
    FT_cl_pid = feedback(FTOriginal * Cs_pid, 1);
    [y_cl_pid, tOut_cl_pid] = step(FT_cl_pid, t);
    hold on; % Permite sobreposição dos gráficos
    plot(tOut_cl_pid, y_cl_pid, 'DisplayName', 'PID');
    
    % Controlador Proporcional-Integral (PI)
    Kp_pi = 0.9 / (R * L);
    Ki_pi = a * 0.27 / (R * L^2);
    
    Cs_pi = Kp_pi + Ki_pi/s;
    % Sistema controlado por PI
    FT_cl_pi = feedback(FTOriginal * Cs_pi, 1);
    [y_cl_pi, tOut_cl_pi] = step(FT_cl_pi, t);
    plot(tOut_cl_pi, y_cl_pi, 'DisplayName', 'PI');
    
    % Configurando o gráfico
    xlabel('Tempo (s)');
    ylabel('Amplitude');
    title(['Resposta ao Degrau (a = ', num2str(a), ')']);
    legend('show');
    hold off; % Finaliza a sobreposição
end
