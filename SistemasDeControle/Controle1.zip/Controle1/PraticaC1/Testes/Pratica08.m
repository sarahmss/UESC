% Definindo a função de transferência original
colors = lines(10);


num_original = 52.8 * [1 22.67 194]; 
den_original = [1 14.16 149 223.83]; 
FTOriginal = tf(num_original, den_original);
% Definindo a função de transferência aproximada via Diagrama de Bode
num_aprox_bode = conv(12.68, conv([1 23.4], [1 23.4])); 
den_aprox_bode = conv([1 1.4], conv([1 10.5], [1 10.5])); 
FTAprox_bode = tf(num_aprox_bode, den_aprox_bode)
FTAproxZpk_bode = zpk(FTAprox_bode)

% Definindo a função de transferência aproximada via resposta ao degrau
num_aprox_deg = 85.6528; 
den_aprox_deg = [1 1.88]; 
FTAprox_deg = tf(num_aprox_deg, den_aprox_deg);
FTAproxZpk_deg = zpk(FTAprox_deg)

% Preparando os LGRs
FTs = {FTOriginal, FTAprox_bode, FTAprox_deg};
titles = {'Original', 'Aproximado por Diagrama de Bode', 'Aproximado por Resposta ao Degrau'};
%%
% tp_aprox <= 0.5 * tp 
% ts_aprox <= 0.5 * ts 
% us_aprox <= 0.1

FT_cl = feedback(FTOriginal, 1);
[y, t] = step(FT_cl);
plot(t, y, 'DisplayName', 'Resposta ao degrau', 'Color', colors(1, :), 'LineWidth', 1.5);

% Determinando o valor final da resposta
valor_final = y(end);
valor_maximo = max(y);

% Calculando tp = p1 / wd
tp = t(find(y == valor_maximo, 1));
tp_ideal = tp * 0.5;
fprintf('O tempo de pico é: %.4f segundos\n', tp);
fprintf(' E precisa ser reduzido para: %.4f segundos\n', tp_ideal);

% Calculando ts
ts = t(find(y >= (valor_final * 0.98), 1));
ts_ideal = ts * 0.5;
fprintf('O tempo de acomodação é: %.4f segundos\n', ts);
fprintf(' E precisa ser reduzido para: %.4f segundos\n', ts_ideal);

% Calculando up
up = (valor_maximo - valor_final)/valor_final;
up_ideal = 0.1;
fprintf('A ultrapassagem percentual é: %.4f \n', up);
fprintf(' E precisa ser reduzido para: %.4f\n', up_ideal);

%% Polo Desejado
sigma = ts_ideal/4;
fprintf('sigma = %.4f \n', sigma);
qsi = -log(up_ideal)/sqrt((pi.^2) + log(up_ideal));
fprintf('qsi = %.4f \n', qsi);
wd = (sigma/qsi) * sqrt(1 - qsi.^2);
fprintf('wd = %.4f \n', wd);
wd_max = pi/tp_ideal; 
fprintf('wd_max = %.4f \n', wd_max);
sd = -sigma + 1i * wd

%% Projeto do controlador
Kc = 0.858 * 10.^(-7)
Pc = 1.0432 * 10.^(-2);

Cs = tf([1  1 0.25], [1 Pc 0]);
CsZpk = zpk(Cs)
rlocus(Kc * Cs * FTAprox_bode)
hold on;
plot(-sigma, wd, 'ro', 'MarkerSize', 8, 'LineWidth', 2);    

%%
t = linspace(0, 100, 500); % Gera 500 pontos de tempo entre 0 e 1.2 segundos
figure;
hold on;
for i = 1:length(FTs)
        FT = FTs{i};
        FT_cl = feedback(Kc * Cs * FT, 1); % Função de transferência em malha fechada
        
        % Resposta ao degrau
        [y, tOut] = step(FT_cl, t); % Simular a resposta ao degrau do sistema em malha fechada
        
        % Plotando cada função de transferência na mesma figura
        plot(tOut, y, 'DisplayName', titles{i}, 'Color', colors(i, :), 'LineWidth', 1.5);
end
% Configurações do gráfico
xlabel('Tempo (s)');
ylabel('Amplitude');
legend('show');
grid on;
title("Resposta ao degrau");
hold off;