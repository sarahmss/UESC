%% Parte 1.0 -  Diagrama de Polos e zeros 
num_g = 1;
colors = lines(6); 

figure;
n = 1;
for c = [1, -1]
    subplot(2, 1, n);
    n = n + 1;
    hold on;
    for tal = 1:5
        den_g = [tal c]; 
        
        FT = tf(num_g, den_g); % Criando a função de transferência
        
        % Convertendo para zero-polo-ganho
        FT_zpk = zpk(FT);
        
        % Obtendo polos e zeros
        polos = pole(FT_zpk);
        zeros_ft = zero(FT_zpk);
        
        % Plotando polos com "x" e zeros com "o", usando uma cor diferente para cada tal
        plot(real(polos), imag(polos), 'x', 'Color', colors(tal,:), 'DisplayName', ['Tal = ', num2str(tal)], 'MarkerSize', 10, 'LineWidth', 2);
        
        if ~isempty(zeros_ft)
            plot(real(zeros_ft), imag(zeros_ft), 'o', 'Color', colors(tal,:), 'MarkerSize', 10, 'LineWidth', 2);
        end
    end

title(['Polos e Zeros em função da variação de tal. caso: ', num2str(c)]);
xlabel('Parte Real');
ylabel('Parte Imaginária');
legend; 
grid on;
hold off;
axis on;
end

%% Parte 1.2 - Resposta ao degrau
figure;
n = 1;
for c = [1, -1]
        subplot(2, 1, n);
        n = n + 1;
        hold on;
    for tal = 1:5
        den_g = [tal c]; 
        
        FT = tf(num_g, den_g); % Criando a função de transferência
        [y,tOut] = step(FT);
        plot(tOut, y, 'Color', colors(tal,:), 'DisplayName', ['Tal = ', num2str(tal)]);   
    end

    title(['Resposta ao degrau em função da variação de tal. caso: ', num2str(c)]);
    xlabel('Parte Real');
    ylabel('Parte Imaginária');
    legend; 
    grid on;
    hold off;
end
%% Parte 2 - Sistema de primeira ordem integrador 
figure;
hold on;

% Definindo a função de transferência
den_g = [1 0]; 
num_g = 1; 
FT = tf(num_g, den_g); 

% Convertendo para zero-polo-ganho
FT_zpk = zpk(FT);

% Plotando os polos
polos = pole(FT_zpk);
subplot(3, 1, 1);
plot(real(polos), imag(polos), 'x', 'Color', colors(1,:), 'MarkerSize', 10, 'LineWidth', 2, 'DisplayName', '1/s');
title('Polos para sistema de primeira ordem integrador');
xlabel('Parte Real');
ylabel('Parte Imaginária');
legend; 
grid on;

t = 0:0.01:10; % Vetor de tempo

% Plotando resposta ao degrau
u_degrau = ones(size(t)); % Entrada de degrau unitário
[y_degrau, tOut_degrau] = lsim(FT, u_degrau, t);

subplot(3, 1, 2);
hold on;
plot(tOut_degrau, y_degrau, 'Color', colors(1,:), 'DisplayName', 'Resposta ao Degrau');
plot(tOut_degrau, u_degrau, 'Color', colors(2,:), 'DisplayName', 'Entrada Degrau');
title('Resposta ao degrau para sistema de primeira ordem integrador');
xlabel('Tempo (s)');
ylabel('Amplitude');
legend; 
grid on;

% Criar o Sinal de Entrada Senoidal
omega = 1; % Frequência do sinal senoidal
u_sin = sin(omega * t); % Sinal de entrada senoidal

% Simular a resposta ao sinal senoidal
[y_senoidal, tOut_senoidal, x] = lsim(FT, u_sin, t);
subplot(3, 1, 3);
hold on;
plot(tOut_senoidal, y_senoidal, 'Color', colors(1,:), 'DisplayName', 'Resposta Senoidal');
plot(tOut_senoidal, u_sin, 'Color', colors(2,:), 'DisplayName', 'Entrada Senoidal');
title('Resposta a entrada senoidal para sistema de primeira ordem integrador');
xlabel('Tempo (s)');
ylabel('Amplitude');
legend;
grid on;

hold off;

%% Parte 3 - Sistema de segunda ordem
figure;
hold on;

% Definindo a função de transferência
num_g = 1; 
den_g = [1 0 25]; 
FT = tf(num_g, den_g); 

% Convertendo para zero-polo-ganho
FT_zpk = zpk(FT);

% Plotando os polos
polos = pole(FT_zpk);
subplot(3, 1, 1);
plot(real(polos), imag(polos), 'x', 'Color', colors(1,:), 'MarkerSize', 10, 'LineWidth', 2, 'DisplayName', '1/s');
title('Polos para sistema de primeira ordem integrador');
xlabel('Parte Real');
ylabel('Parte Imaginária');
legend; 
grid on;

t = 0:0.01:10; % Vetor de tempo

% Plotando resposta ao degrau
u_degrau = ones(size(t)); % Entrada de degrau unitário
[y_degrau, tOut_degrau] = lsim(FT, u_degrau, t);

subplot(3, 1, 2);
hold on;
plot(tOut_degrau, y_degrau, 'Color', colors(1,:), 'DisplayName', 'Resposta ao Degrau');
plot(tOut_degrau, u_degrau, 'Color', colors(2,:), 'DisplayName', 'Entrada Degrau');
title('Resposta ao degrau para sistema de primeira ordem integrador');
xlabel('Tempo (s)');
ylabel('Amplitude');
legend; 
grid on;

n = 1;
for omega = [4, 5, 6] % Frequência do sinal senoidal
    u_sin = sin(omega * t); % Sinal de entrada senoidal
    n = n + 1;
    % Simular a resposta ao sinal senoidal
    [y_senoidal, tOut_senoidal, x] = lsim(FT, u_sin, t);
    subplot(3, 1, 3);
    hold on;
    plot(tOut_senoidal, y_senoidal, 'Color', colors(n,:), 'DisplayName', ['Resposta senoidal, w= ', num2str(omega)]);
    % plot(tOut_senoidal, u_sin, 'Color', colors(n,:), 'DisplayName', ['Entrada senoidal, w= ', num2str(omega)], 'LineStyle','--');
    title('Resposta a entrada senoidal para sistema de primeira ordem integrador');
    xlabel('Tempo (s)');
    ylabel('Amplitude');
    legend; 
    grid on;
end
hold off;

%% Parte 4.1 - Simulação de entrada degrau
num_g1 = 0.8;
den_g1 = [0.5 1.5 1.0];

num_g2 = 1.0;
den_g2 = [1.0 10.0 1.0];

% Plotando Polos e zeros 
for FT = [tf(num_g1, den_g1) tf(num_g2, den_g2)] % Criando a função de transferência
    figure;
    % Convertendo para zero-polo-ganho
    FT_zpk = zpk(FT);
    
    % Obtendo polos e zeros
    polos = pole(FT_zpk);
    zeros_ft = zero(FT_zpk);
    
    % Plotando polos com "x" e zeros com "o", usando uma cor diferente para cada tal
    subplot(2, 1, 1);
    plot(real(polos), imag(polos), 'x', 'Color', colors(tal,:), 'DisplayName', 'Polos', 'MarkerSize', 10, 'LineWidth', 2);
    
    if ~isempty(zeros_ft)
        plot(real(zeros_ft), imag(zeros_ft), 'o', 'Color', colors(tal,:), 'MarkerSize', 10, 'LineWidth', 2);
    end
    
    title('Polos e Zeros em função da variação de tal. Ft=');
    xlabel('Parte Real');
    ylabel('Parte Imaginária');
    legend; 
    grid on;
    hold off;
    axis on;
    
    [y,tOut] = step(FT);
    subplot(2, 1, 2);
    plot(tOut, y, 'Color', colors(tal,:), 'DisplayName', 'Resposta ao degrau');   
    title('Resposta ao degrau em função da variação de tal. FT= ');
    xlabel('Parte Real');
    ylabel('Parte Imaginária');
    legend; 
    grid on;

end

%% Parte 4.2 - Simulação de entrada degrau 
figure;
den_g = [0.5 1.5 1.0]; % Denominador da função de transferência
n = 1;
colors = lines(6); % Gerar uma matriz de cores (para 6 valores de B)

for B = [0.1, 0.6, 0.99, 1.2, 2.0, 10]
    num_g = [(0.8 * B)  0.8]; 
    
    % Criando a função de transferência
    FT = tf(num_g, den_g); 
    
    % Convertendo para zero-polo-ganho
    FT_zpk = zpk(FT);
    
    % Obtendo polos e zeros
    polos = pole(FT_zpk);
    zeros_ft = zero(FT_zpk);
    
    % Plotando polos com "x" e zeros com "o", usando uma cor diferente para cada Bs
    subplot(2, 1, 1);
    hold on;
    if n == 1
        plot(real(polos), imag(polos), 'x', 'Color', colors(n,:), 'DisplayName', 'Polos', 'MarkerSize', 10, 'LineWidth', 2);
    end

    if ~isempty(zeros_ft)
        plot(real(zeros_ft), imag(zeros_ft), 'o', 'Color', colors(n,:), ...
            'DisplayName', ['B = ', num2str(B), ' zero = ', num2str(zeros_ft)], 'MarkerSize', 10, 'LineWidth', 2);
    end
    
    % Plotando resposta ao degrau
    [y, tOut] = step(FT);
    subplot(2, 1, 2);
    hold on;
    plot(tOut, y, 'Color', colors(n,:), 'DisplayName',['B = ', num2str(B), ' zero = ', num2str(zeros_ft)]);   

    n = n + 1;
end

% Configuração do primeiro subplot (Polos e Zeros)
subplot(2, 1, 1);
title('Polos e Zeros em função da variação de B');
xlabel('Parte Real');
ylabel('Parte Imaginária');
legend;
grid on;

% Configuração do segundo subplot (Resposta ao Degrau)
subplot(2, 1, 2);
title('Resposta ao degrau em função da variação de B');
xlabel('Tempo (s)');
ylabel('Amplitude');
legend;
grid on;
hold off;

%% Parte 5.1 - Simulação de entrada degrau
num_g1 = 0.9;
den_g1 = [1.0 1.0 1.0];


% Plotando Polos e zeros 
FT = tf(num_g1, den_g1);
figure;
% Convertendo para zero-polo-ganho
FT_zpk = zpk(FT);

% Obtendo polos e zeros
polos = pole(FT_zpk);
zeros_ft = zero(FT_zpk);

% Plotando polos com "x" e zeros com "o", usando uma cor diferente para cada tal
subplot(2, 1, 1);
plot(real(polos), imag(polos), 'x', 'Color', colors(tal,:), 'DisplayName', 'Polos', 'MarkerSize', 10, 'LineWidth', 2);

if ~isempty(zeros_ft)
    plot(real(zeros_ft), imag(zeros_ft), 'o', 'Color', colors(tal,:), 'MarkerSize', 10, 'LineWidth', 2);
end

title('Polos e Zeros em função da variação de tal. Ft=');
xlabel('Parte Real')
ylabel('Parte Imaginária');
legend; 
grid on;
hold off;
axis on;

[y,tOut] = step(FT);
subplot(2, 1, 2);
plot(tOut, y, 'Color', colors(tal,:), 'DisplayName', 'Resposta ao degrau');   
title('Resposta ao degrau em função da variação de tal. FT= ');
xlabel('Parte Real');
ylabel('Parte Imaginária');
legend; 
grid on;

%% Parte 5.2 - Simulação de entrada degrau 
figure;
den_g = [1.0 1.0 1.0];
n = 1;
colors = lines(6); % Gerar uma matriz de cores (para 6 valores de B)

for B = [0.05, 0.5, 1.0, 2.5]
    num_g = [(0.9 * B)  0.9]; 
    
    % Criando a função de transferência
    FT = tf(num_g, den_g); 
    
    % Convertendo para zero-polo-ganho
    FT_zpk = zpk(FT);
    
    % Obtendo polos e zeros
    polos = pole(FT_zpk);
    zeros_ft = zero(FT_zpk);
    
    % Plotando polos com "x" e zeros com "o", usando uma cor diferente para cada Bs
    subplot(2, 1, 1);
    hold on;
    if n == 1
        plot(real(polos), imag(polos), 'x', 'Color', colors(n,:), 'DisplayName', 'Polos', 'MarkerSize', 10, 'LineWidth', 2);
    end

    if ~isempty(zeros_ft)
        plot(real(zeros_ft), imag(zeros_ft), 'o', 'Color', colors(n,:), ...
            'DisplayName', ['B = ', num2str(B), ' zero = ', num2str(zeros_ft)], 'MarkerSize', 10, 'LineWidth', 2);
    end
    
    % Plotando resposta ao degrau
    [y, tOut] = step(FT);
    subplot(2, 1, 2);
    hold on;
    plot(tOut, y, 'Color', colors(n,:), 'DisplayName',['B = ', num2str(B), ' zero = ', num2str(zeros_ft)]);   

    n = n + 1;
end

% Configuração do primeiro subplot (Polos e Zeros)
subplot(2, 1, 1);
title('Polos e Zeros em função da variação de B');
xlabel('Parte Real');
ylabel('Parte Imaginária');
legend;
grid on;

% Configuração do segundo subplot (Resposta ao Degrau)
subplot(2, 1, 2);
title('Resposta ao degrau em função da variação de B');
xlabel('Tempo (s)');
ylabel('Amplitude');
legend;
grid on;
hold off;

%% Parte 6.0 
num_g = [-1 1];
den_g = [0.5 1.5 1.0];


% Plotando Polos e zeros 
FT = tf(num_g, den_g);
figure;
% Convertendo para zero-polo-ganho
FT_zpk = zpk(FT);

% Obtendo polos e zeros
polos = pole(FT_zpk);
zeros_ft = zero(FT_zpk);

% Plotando polos com "x" e zeros com "o", usando uma cor diferente para cada tal
subplot(2, 1, 1);
hold on;
plot(real(polos), imag(polos), 'x', 'Color', colors(1,:), 'DisplayName', 'Polos', 'MarkerSize', 10, 'LineWidth', 2);

if ~isempty(zeros_ft)
    plot(real(zeros_ft), imag(zeros_ft), 'o', 'Color', colors(1,:), 'MarkerSize', 10, 'LineWidth', 2, 'DisplayName', 'Zeros');
end

title('Polos e Zeros em função da variação de tal. Ft=');
xlabel('Parte Real')
ylabel('Parte Imaginária');
legend; 
grid on;
hold off;
axis on;

[y,tOut] = step(FT);
subplot(2, 1, 2);
plot(tOut, y, 'Color', colors(1,:), 'DisplayName', 'Resposta ao degrau');   
title('Resposta ao degrau em função da variação de tal. FT= ');
xlabel('Parte Real');
ylabel('Parte Imaginária');
legend; 
grid on;
