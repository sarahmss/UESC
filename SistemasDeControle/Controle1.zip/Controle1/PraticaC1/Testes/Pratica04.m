%% Funções de Transferência
colors = lines(10);

% Definindo a função de transferência original
num_original = 52.8 * [1 22.67 194]; 
den_original = [1 14.16 149 223.83]; 
FTOriginal = tf(num_original, den_original);
FTOriginalZpk = zpk(FTOriginal);

% Definindo a função de transferência aproximada via Diagrama de Bode
num_aprox_bode = conv(12.68, conv([1 23.4], [1 23.4])); 
den_aprox_bode = conv([1 1.4], conv([1 10.5], [1 10.5])); 
FTAprox_bode = tf(num_aprox_bode, den_aprox_bode);
FTAproxZpk_bode = zpk(FTAprox_bode);

% Definindo a função de transferência aproximada via resposta ao degrau
num_aprox_deg = 85.6528; 
den_aprox_deg = [1 1.88]; 
FTAprox_deg = tf(num_aprox_deg, den_aprox_deg);
FTAproxZpk_deg = zpk(FTAprox_deg);

%% Resposta ao Degrau

% Plotando a resposta ao degrau para ambas as funções de transferência
t = 0:0.01:40;
figure;
hold on;
[y_orig, tOut_orig] = step(FTOriginal, t);
plot(tOut_orig, y_orig, 'Color', colors(1,:), 'DisplayName', 'Original');

[y_aprox_bode, tOut_aprox_bode] = step(FTAprox_bode, t);
plot(tOut_aprox_bode, y_aprox_bode, 'Color', colors(2,:), 'DisplayName', 'Aproximada via Diagrama de Bode');

[y_aprox_deg, tOut_aprox_deg] = step(FTAprox_deg, t);
plot(tOut_aprox_deg, y_aprox_deg, 'LineStyle', '--',  'Color', colors(3,:), 'DisplayName', 'Aproximada via Resposta ao Degrau');

title('Resposta ao Degrau');
xlabel('Tempo (s)');
ylabel('Amplitude');
legend('show');
grid on;
hold off;

%% Diagrama de Bode
w = 0.1:0.1:100; % Frequências de 0.1 a 100 rad/s
figure;
hold on;

% Diagrama de Bode para a função original
[mag_orig, phase_orig, omega_orig] = bode(FTOriginal, w);
mag_orig = squeeze(mag_orig);
phase_orig = squeeze(phase_orig);
omega_orig = squeeze(omega_orig);

subplot(2, 1, 1);
semilogx(omega_orig, 20*log10(mag_orig), 'Color', colors(1,:), 'LineWidth', 1.5);
hold on;

% Diagrama de Bode para a função aproximada via Diagrama de Bode
[mag_aprox_bode, phase_aprox_bode, omega_aprox_bode] = bode(FTAprox_bode, w);
mag_aprox_bode = squeeze(mag_aprox_bode);
phase_aprox_bode = squeeze(phase_aprox_bode);

semilogx(omega_aprox_bode, 20*log10(mag_aprox_bode), 'Color', colors(2,:), 'LineWidth', 1.5);

% Diagrama de Bode para a função aproximada via resposta ao degrau
[mag_aprox_deg, phase_aprox_deg, omega_aprox_deg] = bode(FTAprox_deg, w);
mag_aprox_deg = squeeze(mag_aprox_deg);
phase_aprox_deg = squeeze(phase_aprox_deg);

semilogx(omega_aprox_deg, 20*log10(mag_aprox_deg), 'Color', colors(3,:), 'LineStyle', '--', 'LineWidth', 1.5);

title('Diagrama de Bode - Magnitude');
ylabel('Magnitude (dB)');
legend('Original', 'Aproximada via Bode', 'Aproximada via Degrau');
grid on;

subplot(2, 1, 2);
semilogx(omega_orig, phase_orig, 'Color', colors(1,:), 'LineWidth', 1.5);
hold on;
semilogx(omega_aprox_bode, phase_aprox_bode, 'Color', colors(2,:), 'LineWidth', 1.5);
semilogx(omega_aprox_deg, phase_aprox_deg, 'Color', colors(3,:), 'LineStyle', '--', 'LineWidth', 1.5);

title('Diagrama de Bode - Fase');
xlabel('Frequência (rad/s)');
ylabel('Fase (graus)');
legend('Original', 'Aproximada via Bode', 'Aproximada via Degrau');
grid on;
hold off;
