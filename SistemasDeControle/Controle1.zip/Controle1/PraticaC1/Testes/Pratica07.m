colors = lines(10); 

% Definindo a função de transferência original
num_original = 52.8 * [1 22.67 194]; 
den_original = [1 14.16 149 223.83]; 
FTOriginal = tf(num_original, den_original);
% Definindo a função de transferência aproximada via Diagrama de Bode
num_aprox_bode = conv(12.68, conv([1 23.4], [1 23.4])); 
den_aprox_bode = conv([1 1.4], conv([1 10.5], [1 10.5])); 
FTAprox_bode = tf(num_aprox_bode, den_aprox_bode)
FTAproxZpk_bode = zpk(FTAprox_bode)

% Definindo a função de transferência aproximada via resposta ao degrau
num_aprox_deg = 85.6528; 
den_aprox_deg = [1 1.88]; 
FTAprox_deg = tf(num_aprox_deg, den_aprox_deg);
FTAproxZpk_deg = zpk(FTAprox_deg)

% Preparando os LGRs
FTs = {FTOriginal, FTAprox_bode, FTAprox_deg};
titles = {'Original', 'Aproximado por Diagrama de Bode', 'Aproximado por Resposta ao Degrau'};

%%
t = linspace(0, 1.4, 500); % Gera 500 pontos de tempo entre 0 e 1.2 segundos
K=1
figure;
hold on;
for i = 1:length(FTs)
        FT = FTs{i};
        FT_cl = feedback(K * FT, 1); % Função de transferência em malha fechada
        
        % Resposta ao degrau
        [y, tOut] = step(FT_cl, t); % Simular a resposta ao degrau do sistema em malha fechada
        
        % Plotando cada função de transferência na mesma figura
        plot(tOut, y, 'DisplayName', titles{i}, 'Color', colors(i, :), 'LineWidth', 1.5);
end
    
% Configurações do gráfico
xlabel('Tempo (s)');
ylabel('Amplitude');
legend('show');
grid on;
title("Resposta ao degrau");
hold off;

%% Controlador por ajuste de ganho 
FT_cl = feedback(FTAprox_bode, 1);

% Resposta ao degrau
[y, t] = step(FT_cl);
plot(t, y, 'DisplayName', 'Resposta ao degrau', 'LineWidth', 1.5);
grid on;
hold on;

% Determinando o valor final da resposta
valor_final = y(end);
valor_maximo = max(y);

% Calculando ultrapassagem percentual
up = (valor_maximo - valor_final) / valor_final;
fprintf('A ultrapassagem percentual é: %.4f \n', up);

% Determinando ultrapassagem percentual ideal
up_ideal = up * 0.5;
fprintf('A ultrapassagem percentual ideal é: %.4f \n', up_ideal);

% Calculando o fator de amortecimento (qsi) e o ângulo correspondente (teta)
qsi = -log(up_ideal) / sqrt(pi^2 + (log(up_ideal))^2);
teta = acos(qsi);
fprintf('Fator de amortecimento desejado: %.4f\n', qsi);
fprintf('Ângulo correspondente (graus): %.2f\n', rad2deg(teta));

% Configuração para análise do LGR
tol = 1e-1; % Tolerância para encontrar o polo com qsi desejado
[r, k_vals] = rlocus(FTAprox_bode); % Calcula polos e ganhos do LGR

% Inicializar variáveis para armazenar o menor erro e o índice correspondente
menor_erro = Inf;
idx_menor_erro = -1;

% Iterar pelos polos no LGR
for i = 1:length(r)
    % Parte real e imaginária do polo
    sigma = real(r(i));
    wd = imag(r(i));
    
    % Calculando qsi no ponto atual do LGR
    qsiInLgr = abs(sigma / sqrt(wd^2 + sigma^2));
    erro_atual = abs(qsi - qsiInLgr);
    
    fprintf('* %.0f : qsi = %.4f | qsi ideal = %.4f | Erro = %.4f\n', i, qsiInLgr, qsi, erro_atual);
    
    % Verificar se este é o menor erro encontrado
    if erro_atual < menor_erro
        menor_erro = erro_atual;
        idx_menor_erro = i;
    end
end

% Verificar se um polo foi encontrado
if idx_menor_erro > 0
    % Obter o polo correspondente e o ganho associado
    polo_selecionado = r(idx_menor_erro);
    k = k_vals(idx_menor_erro);
    
    fprintf('Polo com menor erro encontrado: %.2f + %.2fi\n', real(polo_selecionado), imag(polo_selecionado));
    fprintf('Fator de amortecimento (qsi) do polo: %.4f\n', abs(real(polo_selecionado) / sqrt(real(polo_selecionado)^2 + imag(polo_selecionado)^2)));
    fprintf('Ganho associado: %.4f\n', k);
else
    disp('Nenhum polo encontrado que satisfaça os critérios.');
end
%%
t = linspace(0, 1.4, 500); % Gera 500 pontos de tempo entre 0 e 1.2 segundos
figure;
hold on;
for i = 1:length(FTs)
        FT = FTs{i};
        FT_cl = feedback(k * FT, 1); % Função de transferência em malha fechada
        
        % Resposta ao degrau
        [y, tOut] = step(FT_cl, t); % Simular a resposta ao degrau do sistema em malha fechada
        
        % Plotando cada função de transferência na mesma figura
        plot(tOut, y, 'DisplayName', titles{i}, 'Color', colors(i, :), 'LineWidth', 1.5);
end
    
% Configurações do gráfico
xlabel('Tempo (s)');
ylabel('Amplitude');
legend('show');
grid on;
title("Resposta ao degrau");
hold off;