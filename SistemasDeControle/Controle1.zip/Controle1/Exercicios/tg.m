% Define a função a ser resolvida
f = @(x) 180 + (atan(1.9523*x/(x+8)) - ...
    (atan(1.9523*x/(x+3)) + atan(1.9523*x/(x+6)) + atan(1.9523*x/(x+10))));

% Define uma nova função para minimizar o valor absoluto
f_abs = @(x) abs(f(x));

% Define o intervalo para x entre -6 e -3
x_lower = -6;
x_upper = -3;

% Usa fminbnd para encontrar o valor de x que minimiza f(x) no intervalo
x_sol = fminbnd(f_abs, x_lower, x_upper);

% Verifica se a solução realmente zera a função
tolerance = 1e-6; % Tolerância para considerar a solução válida
if abs(f(x_sol)) < tolerance
    disp(['A solução de x no intervalo é: ', num2str(x_sol)]);
else
    disp('Não foi encontrada uma solução precisa dentro do intervalo.');
end
