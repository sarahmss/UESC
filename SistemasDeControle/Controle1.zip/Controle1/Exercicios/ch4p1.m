%% Obtendo respostas ao degrau de sistemas
% (ch4p1) Exemplo 4.6

p1 = [1 (3 + 7*1i) ];
p2 = [1 (3 - 7*1i) ];

den_g = conv(p1, p2);

omega_n = sqrt( (den_g(3)) /  (den_g(1)))
zeta = (den_g(2)) /  (den_g(1)) / (2 * omega_n)
Ts = 4/(zeta * omega_n)
Tp = pi / (omega_n * sqrt(1 - zeta ^ 2))
up = 100 * exp (-zeta * pi / sqrt(1 - zeta ^ 2))
pause