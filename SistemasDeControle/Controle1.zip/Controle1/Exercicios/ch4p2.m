%% Obtendo respostas ao degrau de sistemas
% (ch4p2) Exemplo 4.8

%% Sistema de segunda ordem simples
clf
num_t1 = 10.5;
den_t1 = [1 12 36.05];
T1 = tf(num_t1, den_t1)

%% Plotar gráficos usando Step

step(T1)
title('Respostas ao degrau de T1(s)');
pause
%% 
FT_zpk = zpk(T1);

% Obtendo polos e zeros
polos = pole(FT_zpk)
zeros_ft = zero(FT_zpk)

figure;

% Plotando polos com "x" e zeros com "o", usando uma cor diferente para cada tal
plot(real(polos), imag(polos), 'x', 'Color', colors(1), 'MarkerSize', 10, 'LineWidth', 2);

if ~isempty(zeros_ft)
    plot(real(zeros_ft), imag(zeros_ft), 'o', 'Color', colors(1), 'MarkerSize', 10, 'LineWidth', 2);
end


title(['Polos e Zeros em função da variação de tal. caso: ', num2str(c)]);
xlabel('Parte Real');
ylabel('Parte Imaginária');
legend; 
grid on;
hold off;
axis on;