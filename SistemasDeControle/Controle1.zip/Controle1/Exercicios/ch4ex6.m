%% Primeira FT
num_g = 700;       
p1 = 15;
p2 = [(-2 + 4 * 1i * sqrt(6)) (-2 - 4 * 1i * sqrt(6))];

den_g = conv(p1, p2);

% Criando a função de transferência
FT = tf(num_g, den_g)

% Plotando polos e zeros
pzmap(FT);
grid on;  % Adiciona o grid ao gráfico
%% Segunda FT