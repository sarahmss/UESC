num_original = [1 1]
den_original = conv([1 0], conv([1 4], conv([1 4], conv([1 2], [1]))))
FTOriginal = tf(num_original, den_original)
FTOriginalZpk = zpk(FTOriginal)

%% Plotando os LGRs na mesma figura
figure;
hold on;
rlocus(FTOriginal); 
hold off;
