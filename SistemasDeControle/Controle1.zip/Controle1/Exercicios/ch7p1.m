%% (ch7p1) Exemplo 7.4, sistema b
numg=500*poly ([-2 -5 -6]);
deng = poly ([0 -8 -10 -12 1]);
G=tf (numg, deng);

% Verifica a Estabilidade
T = feedback (G,1);
polos = pole(T)

% Entrada em Degrau
Kp = dcgain(G)
erp = 1/(1+Kp)

% Entrada em Rampa
numsg = conv([10], numg);
densg = poly([0 -8 -10 -12]);
SG = tf(numsg, densg);
SG = minreal(SG);
Kv = dcgain(SG)
erp=1/Kv

% Entrada em Parábola
nums2g = conv([100], numg);
dens2g = poly([1 -8 -10 -12]);
s2G = tf(nums2g, dens2g);
s2G = minreal(s2G);
Ka = dcgain(s2G)
erp = 1/Ka