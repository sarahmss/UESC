numG = [1 10];
denG = conv([1 3],[1 2 2]);
FTG = tf(numG, denG);
FTGZpk = zpk(FTG)
polos= pole(FTGZpk)

K=80.969;
numC = conv([1 2],[1 2])
denC = conv([1 10.4707], [1 10.4707]);
FTC = tf(numC, denC);
FTCZpk = zpk(FTC)

rlocus(K*FTG*FTC)

T=  feedback (K*FTG*FTC, 1)
polos=pole(T)
zeros = zero(T)
%% Ajuste de ganho
% Definindo os polos desejados
sd1 = -2.0000 + 0.5000i;
sd2 = -2.0000 - 0.5000i;

% Parâmetros iniciais
K_adjusted = 80.969;
tolerance = 1e-3; % tolerância para a proximidade de sd1 e sd2
max_iter = 1000; % número máximo de iterações para evitar loop infinito
iter = 0; % contador de iterações

% Alocação de memória para armazenar outros polos (supondo no máximo 10)
outros_polos = NaN(10, 1); % Inicializando com NaN para até 10 polos
num_outros_polos = 0; % Contador para os polos realmente adicionados

% Loop para ajuste de K
while true
    % Calcular a função de transferência em malha fechada com o ganho atual
    T_adjusted = feedback(K_adjusted * FTG * FTC, 1);
    polos_adjusted = pole(T_adjusted);

    % Reiniciar os outros_polos e num_outros_polos para cada iteração
    outros_polos(:) = NaN; % Limpar o vetor para a próxima iteração
    num_outros_polos = 0; % Resetar o contador

    % Verificar se sd1 e sd2 estão entre os polos e se são os polos dominantes
    is_dominant = false;

    for p = transpose(polos_adjusted)
        if abs(real(p - sd1)) < tolerance && abs(imag(p - sd1)) < tolerance
            is_dominant = true;
        elseif abs(real(p - sd2)) < tolerance && abs(imag(p - sd2)) < tolerance
            is_dominant = true;
        else
            % Adicionar o polo a outros_polos e atualizar o contador
            num_outros_polos = num_outros_polos + 1;
            outros_polos(num_outros_polos) = real(p);
        end
    end

    % Condição de dominância: todos os outros polos têm parte real menor que -8
    if is_dominant && all(outros_polos(1:num_outros_polos) < -8)
        break; % Condição satisfeita, interrompe o loop
    end

    % Incrementa o valor de K e o contador de iterações
    K_adjusted = K_adjusted + 0.01;
    iter = iter + 1;

    % Condição de parada para evitar loop infinito
    if iter > max_iter
        warning('Condição não satisfeita após o número máximo de iterações.');
        break;
    end
end

% Exibir o resultado final
disp(['Ganho ajustado K = ', num2str(K_adjusted)]);
disp('Polos ajustados do sistema em malha fechada:');
disp(polos_adjusted);
disp('Outros polos com parte real menor que -8:');
disp(outros_polos(1:num_outros_polos));

rlocus(K_adjusted*FTG*FTC);

