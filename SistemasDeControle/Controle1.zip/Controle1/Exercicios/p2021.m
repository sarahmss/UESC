%% Obtendo respostas ao degrau de sistemas
% (ch4p2) Exemplo 4.8

%% Sistema de segunda ordem simples
K = 10;
num_t1 = K * 15;
den_t1 = [1 12 (15 * K + 35)];
T1 = tf(num_t1, den_t1)

%% Plotar gráficos usando Step
figure;
step(T1)
title('Respostas ao degrau de T1(s)');
FT_zpk = zpk(T1);

% Obtendo polos e zeros
polos = pole(FT_zpk);
zeros_ft = zero(FT_zpk);

figure;

% Plotando polos com "x" e zeros com "o", usando uma cor diferente para cada um
plot(real(polos), imag(polos), 'x', 'Color', 'b', 'MarkerSize', 10, 'LineWidth', 2);
hold on;
plot(real(zeros_ft), imag(zeros_ft), 'o', 'Color', 'r', 'MarkerSize', 10, 'LineWidth', 2);

title(['Polos e Zeros em função da variação de tal. caso: ', num2str(c)]);
xlabel('Parte Real');
ylabel('Parte Imaginária');
legend('Polos', 'Zeros');
grid on;
hold off;
axis on;

%% Lugar geometrico das raizes
figure;

% Plotar o lugar das raízes
rlocus(T1);

% Adicionar título e rótulos aos eixos
title('Lugar das Raízes da Função de Transferência');
xlabel('Parte Real');
ylabel('Parte Imaginária');

% Adicionar uma grade para melhor visualização
grid on;
