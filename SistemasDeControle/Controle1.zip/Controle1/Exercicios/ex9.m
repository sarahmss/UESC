G = tf([1 8],  conv([1 3], conv([1 6], [1 10])))
[y, tOut] = step(feedback(121.5 * G, 1));
plot(tOut, y, color='red');
hold on;
G_zpk = zpk(G)
Kc = 16.337
C = tf(conv([1 14.574], [1 14.574]), [1 0])
C_zpk = zpk(C)

FT_cl = feedback(G * C * Kc, 1)
FT_cl_zpk = zpk(FT_cl)
[y_cl, tOut_cl] = step(FT_cl);

plot(tOut_cl, y_cl, color='blue');
%%
G = tf(2,  conv([1 1], conv([1 6], [1 10])))
G_zpk = zpk(G)

rlocus(G);
% [y, tOut] = step(feedback(G, 1));
% plot(tOut, y, color='red');
%% 
Kc = 18.059
C = tf(conv([1 4.118], [1 4.118]), [1 0])
C_zpk = zpk(C)
figure;
rlocus(G*C);
%%
% Definir os parâmetros
z1 = 4.118;
z2 = z1;
Kp = Kc * (z1 + z2)
Ki = Kc * (z1 * z2)
Kd = Kc
N = 2000;

% Criar o controlador
s = tf('s'); % Definir a variável de Laplace
C2 = Kp + Ki/s + ((Kd *s * N) / (s + N))

% Exibir o controlador
figure;
rlocus(G*C2);

%% 
FT_cl = feedback(G * C2 * Kc, 1)
FT_cl_zpk = zpk(FT_cl)
pole(FT_cl_zpk)
zero(FT_cl_zpk)


%%
[y_cl, tOut_cl] = step(FT_cl);
plot(tOut_cl, y_cl, color='blue');