%% (ch7p2) Exemplo 7.6
numgdk = 15;
dengdK = poly([0 -6 -7 -8])
GdK = tf(numgdk, dengdK)
numgkv = conv(10, numgdk);
dengkv = dengdK
GKv = tf(numgkv,dengkv)
GKv = minreal (GKv)
KvdK = dcgain (GKv)
erp = 0.1
K = 1/(erp*KvdK)

% Verifica a Estabilidade
T= feedback (K*GdK, 1)
polos=pole (T)
pause