open("Pratica05.fem")

-- Salvar em um novo arquivo para realizar os testes sem perder os dados antigos

mi_saveas("temp.fem")

file_descriptor = openfile("variando_distancia.txt", "a");
write(file_descriptor,
  "\t Energia magnética [J]",
  "\t Indutância [H]",
  "\t Força magnética [N]", "\n");
closefile(file_descriptor)


up_y1 = -12.0
down_y1 = -14.0
distance = abs(up_y1 - down_y1)
x1_rec, y1_rec, x2_rec, y2_rec = -1.0, -10.0, 6.0, -13.5
x_label, y_label = 2.5, -12.0
dy = -0.1
Material = 'Carpenter Silicon Core Iron "A", 1066C Anneal'

while distance > 0.1 do
  -- Movendo segmentos
  mi_clearselected()
  mi_selectrectangle(x1_rec, y1_rec, x2_rec, y2_rec, 4)
  mi_movetranslate(0.0, dy)
  mi_clearselected()

  mi_selectlabel(x_label, y_label)
  mi_deleteselectedlabels()
  mi_clearselected()

  y_label = y_label + dy

  mi_addblocklabel(x_label, y_label)
  mi_selectlabel(x_label, y_label)
  mi_setblockprop(Material)
  mi_clearselected()

  -- Atualizando a distancia
  up_y1 = up_y1 + dy
  distance = abs(up_y1 - down_y1)
  y1_rec = y1_rec + dy
  y2_rec = y2_rec + dy

  mi_createmesh(0)
  mi_analyse()      -- Analise do problema, criação das malhas
  mi_loadsolution() -- Solução das malhas pelo método definido
  mi_zoomnatural()  -- Zoom natural para melhor visão do motor

  mo_showdensityplot(0, 0, 1.06589872126296, 4.21621346869572e-005, "mag")
  mo_savebitmap(format("variando_distancia%1$.1f.bmp", distance))

  --- Concertar calculo
  Energia = 0
  Indutancia = 0
  Forca = 0


  file_descriptor = openfile("variando_distancia.txt", "a");
  write(file_descriptor,
    Energia, "\t",
    Indutancia, "\t",
    Forca, "\n");
  closefile(file_descriptor)
end
