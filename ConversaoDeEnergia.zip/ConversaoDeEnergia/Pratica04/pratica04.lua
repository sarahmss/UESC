--------------------------------------------------------------------
--- Prática 04 - Conversão de Energia
--- Discentes:  Angela Marim Bosetti (202012309),
---             Allan Cristhian Barbosa (202012323),
---             Sarah Modesto Sanches (202012319)
--------------------------------------------------------------------

--- OBS: CONCERTAR A FRONTEIRA (ESTÁ INDO COMO M5-STEEL E NÃO AIR)

-- Inicialização do ambiente FEMM
newdocument(0)

--- Definição do Problema
mi_probdef(60, 'centimeters', "planar", 1E-8, 2, 30, 0)

--- Definição dos Materiais
coreType = "M-45 Steel"
coilType = "18 AWG"
boundaryType = "Air"

-- Adição dos materiais ao projeto
mi_getmaterial(coreType)
mi_getmaterial(coilType)
mi_getmaterial(boundaryType)

------------------------- Definição da fronteira -----------------------
-- ABC: Asymptotic Boundary Condition
mi_addboundprop("ABC", 0, 0, 0, 0, 0, 0, 0, 0, 0)

mi_addnode(-14.5, 16.3)
mi_addnode(53.4, 16.3)
mi_addarc(-14.5, 16.3, 53.4, 16.3, 180, 1)
mi_addarc(53.4, 16.3, -14.5, 16.3, 180, 1)

mi_selectarcsegment(16.3, -14.5)
mi_setarcsegmentprop(1, "ABC", 0, 0)
mi_clearselected()

mi_selectarcsegment(16.3, 53.4)
mi_setarcsegmentprop(1, "ABC", 0, 0)
mi_clearselected()

mi_refreshview()

--------------------------- Pontos ----------------------------
mi_addnode(0,0)
mi_addnode(0,6.6)
mi_addnode(0,26)
mi_addnode(0,32.6)
mi_addnode(-1.25,8.5) 
mi_addnode(-3.5,8.5)
mi_addnode(-3.5,24)
mi_addnode(-1.25,24)
mi_addnode(40.6,32.6)
mi_addnode(40.6,26)
mi_addnode(40.6,6.6)
mi_addnode(44.75,6.6)
mi_addnode(44.75,26)
mi_addnode(41.75,24)
mi_addnode(41.75,8.5)
mi_addnode(44,24)
mi_addnode(44,8.5)
mi_addnode(8,6.6)
mi_addnode(8,26)
mi_addnode(12.15,26)
mi_addnode(12.5,6.6)
mi_addnode(16.3,6.6) 
mi_addnode(16.3,26)
mi_addnode(9.25,8.5) 
mi_addnode(9.25,24)
mi_addnode(11.5,24)
mi_addnode(11.5,8.5) 
mi_addnode(12.8,8.5)
mi_addnode(12.8,24)
mi_addnode(15.05,8.5)
mi_addnode(15.05,24)
mi_addnode(25.55,8.5)
mi_addnode(25.55,24)
mi_addnode(27.8,24)
mi_addnode(27.8,8.5)
mi_addnode(29.1,8.5)
mi_addnode(29.1,24)
mi_addnode(31.35,24)
mi_addnode(31.35,8.5)
mi_addnode(24.3,6.6)
mi_addnode(24.3,26)
mi_addnode(28.45,26)
mi_addnode(32.6,26)
mi_addnode(32.6,6.6)
mi_addnode(28.45,6.6)
mi_addnode(24.3,6.6)
mi_addnode(40.5,0)
mi_addnode(-5, 26)
mi_addnode(-5, 6.5)

----------------------- Bobinas ------------------------


------------------ Nucleo magnetico ----------------
-- externo --
mi_addsegment(0, 0, 0, 32.6)
mi_addsegment(0, 32.6, 32.6, 40.5)
mi_addsegment(32.6, 40.5, 40.5, 0)
mi_addsegment(40.5, 0, 0, 0)

-- interno esquerda --
mi_addsegment(8, 26, 8, 6.5)
mi_addsegment(8,26, 16.3, 26)
mi_addsegment(16.3, 26, 16.3, 6.5)
mi_addsegment(16.3, 6.5, 8, 6.5)

-- interno direita --
mi_addsegment(24, 26, 24, 6.5)
mi_addsegment(24,26, 32, 26)
mi_addsegment(32, 26, 32, 6.5)
mi_addsegment(32, 6.5,24, 6.5)

-- bobina 1 --
mi_addsegment(12, 26, 12, 6.6)
mi_addsegment(0, 26, -5, 26)
mi_addsegment(-5, 26, -5, 6.5)
mi_addsegment(-5, 6.5, 0, 6.5)

mi_addsegment(-1.3, 8.5, -3.6, 8.5)
mi_addsegment(-3.6, 8.5, -3.6, 24)
mi_addsegment(-3.6, 24, -1.3, 24)
mi_addsegment(-1.3, 24, -1.3, 8.5)

mi_addsegment(-1.3, 8.5, -3.6, 8.5)
mi_addsegment(-3.6, 8.5, -3.6, 24)
mi_addsegment(-3.6, 24, -1.3, 24)
mi_addsegment(-1.3, 24, -1.3, 8.5)

mi_addsegment(9.2, 8.5, 11.3, 8.5)
mi_addsegment(11.3, 8.5, 11.3, 24)
mi_addsegment(11.3, 24, 9.2, 24)
mi_addsegment(9.2, 24, 9.2, 8.5)

mi_addsegment(12.7, 8.5, 15, 8.5)
mi_addsegment(15, 8.5, 15, 24)
mi_addsegment(15, 24, 12.7, 24)
mi_addsegment(12.7, 24, 12.7, 8.5)

mi_addsegment(25.5, 8.5, 27.8, 8.5)
mi_addsegment(27.8, 8.5, 27.8, 24)
mi_addsegment(27.8, 24, 25.5, 24)
mi_addsegment(25.5, 24, 25.5, 8.5)


mi_addsegment(29, 8.5, 31.3, 8.5)
mi_addsegment(31.3, 8.5, 31.3, 24)
mi_addsegment(31.3, 24, 29, 24)
mi_addsegment(29, 24, 29, 8.5)

mi_addsegment(41.7, 8.5, 44, 8.5)
mi_addsegment(44, 8.5, 44, 24)
mi_addsegment(44, 24, 41.7, 24)
mi_addsegment(41.7, 24, 41.7, 8.5)

mi_addsegment(40.6, 26, 40.6, 6.5)
mi_addsegment(40.6,26, 44.8, 26)
mi_addsegment(44.8, 26, 44.8, 6.5)
mi_addsegment(44.8, 6.5, 40.6, 6.5)

mi_addsegment(28.5, 26, 28.5, 6.5)




mi_refreshview()

----- Propriedades de bloco -------------

--- Fronteira
mi_clearselected()
mi_addblocklabel(19, 40)
mi_selectlabel(19, 40)
mi_setblockprop("Air")

--- Núcleo
mi_clearselected()
mi_addblocklabel(4.5, 4.0)
mi_selectlabel(4.5, 4.0)
mi_setblockprop(coreType, 1, 0, "", 0, 0)

--- Bobina 1 (primário)
mi_clearselected()
mi_addblocklabel(-2.5, 25)
mi_selectlabel(-2.5, 25)
mi_setblockprop(coilType, 0, 0, "Bobina1p", 0, 0, 100)

mi_clearselected()
mi_addblocklabel(10, 25)
mi_selectlabel(10, 25)
mi_setblockprop(coilType, 0, 0, "Bobina1p", 0, 0, -100)

--- Bobina 1 (secundário)
mi_clearselected()
mi_addblocklabel(-2.5, 15)
mi_selectlabel(-2.5, 15)
mi_setblockprop(coilType, 0, 0, "Bobina1s", 0, 0, 400)

mi_clearselected()
mi_addblocklabel(10, 15)
mi_selectlabel(10, 15)
mi_setblockprop(coilType, 0, 0, "Bobina1s", 0, 0, -400)


--- Bobina 2 (primário)
mi_clearselected()
mi_addblocklabel(14, 25)
mi_selectlabel(14, 25)
mi_setblockprop(coilType, 0, 0, "Bobina2p", 0, 0, 100)

mi_clearselected()
mi_addblocklabel(26, 25)
mi_selectlabel(26, 25)
mi_setblockprop(coilType, 0, 0, "Bobina2p", 0, 0, -100)

--- Bobina 2 (secundário)
mi_clearselected()
mi_addblocklabel(14, 15)
mi_selectlabel(14, 15)
mi_setblockprop(coilType, 0, 0, "Bobina2s", 0, 0, 400)

mi_clearselected()
mi_addblocklabel(26, 15)
mi_selectlabel(26, 15)
mi_setblockprop(coilType, 0, 0, "Bobina2s", 0, 0, -400)

--- Bobina 3 (primário)
mi_clearselected()
mi_addblocklabel(30, 25)
mi_selectlabel(30, 25)
mi_setblockprop(coilType, 0, 0, "Bobina3p", 0, 0, 100)

mi_clearselected()
mi_addblocklabel(43, 25)
mi_selectlabel(43, 25)
mi_setblockprop(coilType, 0, 0, "Bobina3p", 0, 0, -100)

--- Bobina 3 (secundário)
mi_clearselected()
mi_addblocklabel(30, 15)
mi_selectlabel(30, 15)
mi_setblockprop(coilType, 0, 0, "Bobina3s", 0, 0, 400)

mi_clearselected()
mi_addblocklabel(43, 15)
mi_selectlabel(43, 15)
mi_setblockprop(coilType, 0, 0, "Bobina3s", 0, 0, -400)



-------------- Adição do circuito ------------------    



mi_addcircprop('Bobina1p', 0.4, 1)
mi_addcircprop('Bobina1s', 0, 1)
mi_addcircprop('Bobina2p', -0.20-I*0.34641, 1)
mi_addcircprop('Bobina2s', 0, 1)
mi_addcircprop('Bobina3p', -0.20+I*0.34641, 1) 
mi_addcircprop('Bobina3s', 0, 1) 


---------------- Malha e análise --------------------
mi_saveas("Pratica04.fem")
mi_createmesh(0)
mi_analyze(1)
mi_loadsolution()
mi_zoomnatural()
mo_showvectorplot(1, 0.5)
mo_showdensityplot(1, 0, 1, 0, "bmag")
mo_savebitmap("Pratica04.fem")

