--------------------------------------------------------------------
--- Prática 03 - Conversão de Energia
--- Discentes:  Angela Marim Bosetti (202012309),
---             Allan Cristhian Barbosa (202012323),
---             Sarah Modesto Sanches (202012319)
--------------------------------------------------------------------

-- Inicialização do ambiente FEMM
newdocument(0)

--- Definição do Problema
mi_probdef(0, 'centimeters', "planar", 1E-8, 2, 30, 0)

--- Definição dos Materiais
coreType = "M-45 Steel"
coilType = "18 AWG"
boundaryType = "Air"

-- Adição dos materiais ao projeto
mi_getmaterial(coreType)
mi_getmaterial(coilType)
mi_getmaterial(boundaryType)

------------------------- Definição da fronteira -----------------------
-- ABC: Asymptotic Boundary Condition
mi_addboundprop("ABC", 0, 0, 0, 0, 0, 0, 0, 0, 0)

mi_addnode(-6, 4.5)
mi_addnode(15, 4.5)
mi_addarc(-6, 4.5, 15, 4.5, 180, 1)
mi_addarc(15, 4.5, -6, 4.5, 180, 1)

mi_selectarcsegment(4.5, -6)
mi_setarcsegmentprop(1, "ABC", 0, 0)
mi_clearselected()

mi_selectarcsegment(4.5, 15)
mi_setarcsegmentprop(1, "ABC", 0, 0)
mi_clearselected()

mi_refreshview()

--------------------------- Bobina ----------------------------

mi_addnode(-1, 6)
mi_addnode(-1, 3)
mi_addnode(3, 3)
mi_addnode(3, 6)
mi_addnode(6, 6)
mi_addnode(6, 3)
mi_addnode(10, 6)
mi_addnode(10, 3)
mi_addnode(0, 6)
mi_addnode(0, 3)
mi_addnode(2, 6)
mi_addnode(2, 3)
mi_addnode(7, 6)
mi_addnode(7, 3)
mi_addnode(9, 6)
mi_addnode(9, 3)


mi_addsegment(-1, 6, 0, 6) --- seg B1 top1
mi_addsegment(-1, 6, -1, 3) --- seg B1 left
mi_addsegment(-1, 3, 0, 3) --- seg B1 bottom1
mi_addsegment(2, 6, 3, 6) --- seg B1 top2
mi_addsegment(3, 6, 3, 3) --- seg B1 rigth
mi_addsegment(3, 3, 2, 3) --- seg B1 bottom2

mi_addsegment(6, 6, 7, 6) --- seg B2 top1
mi_addsegment(6, 6, 6, 3) --- seg B2 left
mi_addsegment(6, 3, 7, 3) --- seg B2 bottom1
mi_addsegment(9, 6, 10, 6) --- seg B2 top2
mi_addsegment(10, 6, 10, 3) --- seg B2 rigth
mi_addsegment(10, 3, 9, 3) --- seg B2 bottom2

------------------ Nucleo magnetico ----------------
mi_addnode(0.0, 0.0)
mi_addnode(0.0, 3.0)
mi_addnode(0.0, 6.0)
mi_addnode(0.0, 9.0)
mi_addnode(2.0, 7.0)
mi_addnode(2.0, 6.0)
mi_addnode(2.0, 3.0)
mi_addnode(2.0, 2.0)
mi_addnode(-1.0, 3.0)
mi_addnode(-1.0, 6.0)
mi_addnode(3.0, 3.0)
mi_addnode(3.0, 6.0)
mi_addnode(9.0, 0.0)
mi_addnode(9.0, 3.0)
mi_addnode(9.0, 6.0)
mi_addnode(9.0, 9.0)
mi_addnode(7.0, 7.0)
mi_addnode(7.0, 6.0)
mi_addnode(7.0, 3.0)
mi_addnode(7.0, 2.0)
mi_addnode(6.0, 6.0)
mi_addnode(6.0, 3.0)
mi_addnode(10.0, 6.0)
mi_addnode(10.0, 3.0)



mi_addsegment(0.0, 9.0, 9.0, 9.0)
mi_addsegment(9.0, 9.0, 9.0, 0.0)
mi_addsegment(0.0, 0.0, 9.0, 0.0)
mi_addsegment(0.0, 0.0, 0.0, 9.0)

mi_addsegment(2.0, 7.0, 7.0, 7.0)
mi_addsegment(7.0, 7.0, 7.0, 2.0)
mi_addsegment(7.0, 2.0, 2.0, 2.0)
mi_addsegment(2.0, 2.0, 2.0, 7.0)



mi_refreshview()

----- Propriedades de bloco -------------

--- Fronteira
mi_clearselected()
mi_addblocklabel(5.5, 14.0)
mi_selectlabel(5.5, 14.0)
mi_setblockprop("Air", 1, 0, "", 0, 0)
mi_addblocklabel(4.5, 4.0)
mi_selectlabel(4.5, 4.0)
mi_setblockprop("Air", 1, 0, "", 0, 0)


--- Nucleo
mi_clearselected()
mi_addblocklabel(7, 8)
mi_selectlabel(7, 8)
mi_setblockprop(coreType, 0, 0, "", 0, 0)

--- Bobina 1
mi_clearselected()
mi_addblocklabel(-0.5, 4)
mi_selectlabel(-0.5, 4)
mi_setblockprop(coilType, 0, 0, "Bobina1", 0, 0, 800)

mi_clearselected()
mi_addblocklabel(2.5, 4)
mi_selectlabel(2.5, 4)
mi_setblockprop(coilType, 0, 0, "Bobina1", 0, 0, -800)

--- Bobina 2
mi_clearselected()
mi_addblocklabel(6.5, 4)
mi_selectlabel(6.5, 4)
mi_setblockprop(coilType, 0, 0, "Bobina2", 0, 0, 200)

mi_clearselected()
mi_addblocklabel(9.5, 4)
mi_selectlabel(9.5, 4)
mi_setblockprop(coilType, 0, 0, "Bobina2", 0, 0, -200)

--- Adição do circuito

mi_addcircprop('Bobina1', 2.0, 1)
mi_addcircprop('Bobina2', 2.0, 1) --- sentido contrario

---------- Malha e análise -------------------------
mi_saveas("Pratica03.fem")
mi_createmesh(0)
mi_analyze(1)
mi_loadsolution()
mi_zoomnatural()
mo_showvectorplot(1, 0.5)
mo_showdensityplot(1, 0, 1, 0, "bmag")
mo_savebitmap("Pratica03.fem")
