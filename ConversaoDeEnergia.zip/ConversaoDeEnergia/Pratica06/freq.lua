--------------------------------------------------------------------
--- Prática 06 - Conversão de Energia
--- Discentes:  Angela Marim Bosetti (202012309),
---             Allan Cristhian Barbosa (202012323),
---             Sarah Modesto Sanches (202012319)
--------------------------------------------------------------------

open("Pratica06.fem")

-- Salvar em um arquivo temporario

mi_saveas("temp.fem")

-- Laço para a extração dos dados do comportamento da tensão e da corrente no secundário do transformador, do fluxo magnético e das perdas magnéticas.

file_descriptor = openfile("dados-frequencia.txt", "a");
write(file_descriptor, "F[Hz]", "\t",
      "B_real [Wb/m]", "\t",
      "B_im [Wb/m]", "\t",
      "Perdas no rotor femm [Wb.e]", "\t",
      "Perdas no estator femm [Wb.e]", "\n")

closefile(file_descriptor)

for f = 0, 2, 0.25 do

      mi_probdef(f, 'millimeters', "planar", 1E-8, 100, 20, 0)

      mi_createmesh(0)
      mi_analyse()
      mi_loadsolution()
      mi_zoomnatural()

      mo_showdensityplot(1, 0, 0.855565861312273, 0, "bmag")
      mo_savebitmap(format("frequencia_%1$d_[e].bmp", f))

      --- Densidade de fluxo no entreferro
      mo_clearcontour()
      mo_addcontour(40.15, 0)
      mo_addcontour(-40.15, 0)
      mo_bendcontour(180, 1)
      B = mo_lineintegral(0)


      --- Perdas no Rotor
      mi_clearselected()
      mo_selectblock(5.0, 20.0)
      rotor_losses = mo_blockintegral(6)

      --- Perdas no estator
      mi_clearselected()
      mo_selectblock(0.0, 60.0)
      estator_losses = mo_blockintegral(6)

      -- Finaliza o processo e
      file_descriptor = openfile("dados-frequencia.txt", "a");
      write(file_descriptor,
            f, "\t",
            re(B), "\t",
            im(B), "\t",
            rotor_losses, "\t",
            estator_losses, "\n")

      closefile(file_descriptor)

end
