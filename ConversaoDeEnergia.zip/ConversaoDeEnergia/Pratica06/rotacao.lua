open("Pratica06.fem")

-- Salvar em um novo arquivo para realizar os testes sem perder os dados antigos

mi_saveas("temp.fem")

file_descriptor = openfile("rotacionar.txt", "a");
write(file_descriptor,
  "angulo [graus]", "\t",
  "B_real[Wb/m]", "\t",
  "B_img [Wb/m]", "\n");

closefile(file_descriptor)
R = 40.2
dteta = 30
angle = 0

iA = 1;
iB = -0.5 + I * 0.86603;
iC = -0.5 - I * 0.86603;


while angle ~= 390 do

  --- rotação do rotor
  mi_clearselected()
  mi_selectcircle(0.0, 0.0, R, 4)
  mi_moverotate(0.0, 0.0, -dteta, 4)
  mi_clearselected()

  --- variação da fase da corrente
  mi_modifycircprop("A", 1, iA)
  mi_modifycircprop("B", 1, iB)
  mi_modifycircprop("C", 1, iC)

  mi_createmesh(0)
  mi_analyse() -- Analise do problema, criação das malhas
  mi_loadsolution() -- Solução das malhas pelo método definido
  mi_zoomnatural() -- Zoom natural para melhor visão do motor

  mo_showdensityplot(0, 0, 1.06589872126296, 4.21621346869572e-005, "mag")
  mo_savebitmap(format("rotacionar%1$.1f.bmp", angle))

  --- Densidade de fluxo no entreferro
  mo_clearcontour()
  mo_addcontour(40.15, 0)
  mo_addcontour(-40.15, 0)
  mo_bendcontour(180, 1)
  B = mo_lineintegral(0)

  file_descriptor = openfile("rotacionar.txt", "a");
  write(file_descriptor,
    angle, "\t",
    re(B), "\t",
    im(B), "\n")

  closefile(file_descriptor)
  --- atualização das variaveis
  angle = angle + dteta
  iA = iA * (0.86603 + I * 0.5)
  iB = iB * (0.86603 + I * 0.5)
  iC = iC * (0.86603 + I * 0.5)
end
