--------------------------------------------------------------------
--- Prática 06 - Conversão de Energia
--- Discentes:  Angela Marim Bosetti (202012309),
---             Allan Cristhian Barbosa (202012323),
---             Sarah Modesto Sanches (202012319)
--------------------------------------------------------------------

--- 0.86603+I*0.5 -> defasamento 30 graus

-- abrir o arquivo usado
open("Pratica06.fem")

-- Salvar em um arquivo temporario
mi_saveas("temp.fem")

file_descriptor = openfile("variando_fase.txt", "a");
write(file_descriptor,
  "angulo [graus]", "\t",
  "B_real[Wb/m]", "\t",
  "B_img [Wb/m]", "\n");

closefile(file_descriptor)

iA = 1;
iB = -0.5 + I * 0.86603;
iC = -0.5 - I * 0.86603;

-- Variando a fase
for c = 0, 12, 1 do
  mi_modifycircprop("A", 1, iA)
  mi_modifycircprop("B", 1, iB)
  mi_modifycircprop("C", 1, iC)
  mi_createmesh(0)
  mi_analyse()
  mi_loadsolution()
  mi_zoomnatural()

  mo_showdensityplot(1, 0, 0.855565861312273, 0, "bmag")
  mo_savebitmap(format("Fase %1$.1f.bmp", c))

  --- Densidade de fluxo no entreferro
  mo_clearcontour()
  mo_addcontour(40.15, 0)
  mo_addcontour(-40.15, 0)
  mo_bendcontour(180, 1)
  B = mo_lineintegral(0)


  file_descriptor = openfile("variando_fase.txt", "a");
  write(file_descriptor,
    angle, "\t",
    re(B), "\t",
    im(B), "\n")

  closefile(file_descriptor)

  iA = iA * (0.86603 + I * 0.5)
  iB = iB * (0.86603 + I * 0.5)
  iC = iC * (0.86603 + I * 0.5)

end
