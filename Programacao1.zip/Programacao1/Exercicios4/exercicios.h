/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exercicios.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: smodesto <smodesto@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/21 14:53:23 by smodesto          #+#    #+#             */
/*   Updated: 2021/09/21 14:53:23 by smodesto         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef EXERCICIOS_H
# define EXERCICIOS_H

# include <stdio.h>
# include <stdlib.h>
# include <stdio.h>
# include <string.h>
# include <iostream>
# include <math.h>


#endif
