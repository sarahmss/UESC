This folder stores:All LaTeX symbols of Tinn-R.It is user customizable!
