This folder stores the files:Tinn.ini and Tinn_dock.ini.
