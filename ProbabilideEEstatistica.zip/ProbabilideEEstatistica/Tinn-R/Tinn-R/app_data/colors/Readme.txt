This folder stores the file:Custom.txt.
