#------------------------------------------------------------------------
# This script runs always when Tinn-R identifies an R instance.
# Aim:
# - Set automatically some options related to R
# - Obtaining essential information regarding of R
# - Install TinnRcom package and its dependencies
#------------------------------------------------------------------------
#.. Please, do not change if you do not know what you're doing!
# J.C.Faria - Tinn-R Team
# 01/06/2021 20:38:47
#------------------------------------------------------------------------

# The tcltk package is necessary to show messages inside a TK windows
# - to choose the R repository
# - to choice packages, ...
options(defaultPackages=c(getOption("defaultPackages"),
                          "tcltk"))

# Set repos: Rterm does not always shows the dialog to choose the repository
# The 'repos' will be set by Tinn-R according to user preference
options('repos'='%repos')

# Limitation of the max.print
options('max.print'=1e4)

# Default: if under Windows OS it will install/update only binary packages
if(Sys.info()[['sysname']] == 'Windows'){
  options(pkgType='win.binary')
  options(install.packages.check.source='no')
}

# Workaround bug: MRO and svSocket
unlockBinding("last.warning",
              baseenv())

# Debug package: necessary under Rterm interface
options(debug.catfile="stdout")

# Info: s_info will be the file where R will save info
if(Sys.info()[['sysname']] == 'Windows')
{
  s_info <- paste(Sys.getenv('TEMP'),
                 'Tinn-R',
                 'info.txt',
                 sep='\\')
} else {
  s_info <- paste('/tmp',
                 'Tinn-R',
                 'info.txt',
                 sep='/')
}

# TinnRcom's dependencies
s_dep_packs <- c('formatR',
                 'svMisc',
                 'svSocket')

# Installed packages
s_ins_packs <- row.names(installed.packages())

# All necessary packages are installed?
b_dep_packs <- all(s_dep_packs %in% s_ins_packs)

# Path: formatR package
s_formatR_path <- try(find.package('formatR'),
                      silent=TRUE)

# Path: svMisc package
s_svMisc_path <- try(find.package('svMisc'),
                     silent=TRUE)

# Path: svSocket package
s_svSocket_path <- try(find.package('svSocket'),
                       silent=TRUE)

# Path: TinnRcom package
s_TinnRcom_path <- try(find.package('TinnRcom'),
                       silent=TRUE)

# If s_formatR_path exists get the version
if(file.exists(s_formatR_path))
{
  s_formatR_version <- try(packageVersion('formatR'),
                           silent=TRUE)
} else {
  s_formatR_version <- '0.0.0'
}

# If s_svMisc_path exists get the version
if(file.exists(s_svMisc_path))
{
  s_svMisc_version <- try(packageVersion('svMisc'),
                          silent=TRUE)
} else {
  s_svMisc_version <- '0.0.0'
}

# If s_svSocket_path exists get the version
if(file.exists(s_svSocket_path))
{
  s_svSocket_version <- try(packageVersion('svSocket'),
                            silent=TRUE)
} else {
  s_svSocket_version <- '0.0.0'
}

# If s_TinnRcom_path exists get the version
if(file.exists(s_TinnRcom_path))
{
  s_TinnRcom_version <- try(packageVersion('TinnRcom'),
                            silent=TRUE)
} else {
  s_svSocket_version <- '0.0.0'
}

# If any dependency is not installed or
# TinnRcom is not installed or
# the TinnRcom version is old: it will try to install TinnRcom and its dependencies
if(
  !b_dep_packs ||
  !file.exists(s_TinnRcom_path) ||
  s_formatR_version < '1.7'     ||
  s_svMisc_version < '1.1.4'    ||
  s_svSocket_version < '1.0.2'  ||
  s_TinnRcom_version < '1.0.21'
  )
{
  # Path of user R library
  s_lib_user <- Sys.getenv('R_LIBS_USER')

  # Check if the folder exists
  if (!dir.exists(s_lib_user))
  {
    dir.create(s_lib_user,
               recursive=TRUE)
  }

  # Workdir: stores old
  s_wd_old <- getwd()

  # Workdir: set new
  # The 'path' will be set by Tinn-R according to its structure
  setwd('%path')

  # The 'install' will be set by Tinn-R according to user preference
  if(%install)
  {
    # Packages: necessary
    if(Sys.info()[['sysname']] == 'Windows')
    {
      s_packs <- c('formatR_1.7.zip',
                   'svMisc_1.1.4.zip',
                   'svSocket_1.0.2.zip',
                   'TinnRcom_1.0.21.zip')
    } else {
      s_packs <- c('formatR_1.7.tar.gz',
                   'svMisc_1.1.4.tar.gz',
                   'svSocket_1.0.2.zip',
                   'TinnRcom_1.0.21.tar.gz')
    }

    # Packages: install
    if(Sys.info()[['sysname']] == 'Windows')
    {
      install.packages(s_packs,
                       lib=s_lib_user,
                       type='win.binary',
                       repos=NULL)
    } else {
      install.packages(s_packs,
                       lib=s_lib_user,
                       repos=NULL)
    }

    # Objects: remove
    rm(s_packs)
  }

  # Workdir: restores old
  setwd(s_wd_old)

  # Library: add new
  .libPaths(new=s_lib_user)

  # Objects: remove
  rm(s_lib_user,
     s_wd_old)
}

# Path: TinnRcom package
s_TinnRcom_path <- try(find.package('TinnRcom'),
                  silent=TRUE)

if(file.exists(s_TinnRcom_path))
{
  s_TinnRcom_path <- try(find.package('TinnRcom'),
                    silent=TRUE)

  s_TinnRcom_version <- try(packageVersion('TinnRcom'),
                     silent=TRUE)
} else {
  s_TinnRcom_path <- 'Not installed'
  s_TinnRcom_version <- '0.0.0'
}

# R: path
s_r_home <- R.home('bin')

# Connection: write
sink(s_info)
  cat(s_r_home,
      s_TinnRcom_path,
      as.character(s_TinnRcom_version),
      .libPaths(),
      fill=1)
sink()

# Package TinnRcom: require
# The 'load' will be set to TRUE or FALSE by Tinn-R according to user preference
if(%load)
{
  if(file.exists(s_TinnRcom_path))
  {
    require(TinnRcom,
            quietly=TRUE)
  }
}

# Package svSocket: require and connect
# The 'connect' will be set to TRUE or FALSE by Tinn-R according to user preference
if(%connect)
{
  if(file.exists(s_svSocket_path))
  {
    require(svSocket,
            quietly=TRUE)
  }
}

# Objects: remove
rm(
  b_dep_packs,
  s_info,
  s_r_home,
  s_dep_packs,
  s_ins_packs,
  s_formatR_path,
  s_svMisc_path,
  s_svSocket_path,
  s_TinnRcom_path,
  s_formatR_version,
  s_svMisc_version,
  s_svSocket_version,
  s_TinnRcom_version
)

# Mirros: update
# The 'mirrors' will be set to TRUE or FALSE by Tinn-R according to user preference
if(%mirrors)
{
  source('%input')
}
