#------------------------------------------------------------------------
# This script runs under request.
# Aim:
# - Obtaining essential information regarding of R mirrors
#------------------------------------------------------------------------
#.. Please, do not change if you do not know what you're doing!
# J.C.Faria - Tinn-R Team
# 01/06/2021 21:31:43
#------------------------------------------------------------------------

# Temp: \Users\user\AppData\Local\Temp\Tinn-R\mirrors.txt
s_mirrors_tmp <- paste(Sys.getenv('TEMP'),
                       'Tinn-R',
                       'mirrors.txt',
                       sep='\\')

# Mirrors: get
s_mirrors <- getCRANmirrors()

# Mirrors: selection of information
s_mirrors <- subset(s_mirrors,
                    select=c('Name',
                             'Country',
                             'City',
                             'URL',
                             'Host',
                             'CountryCode'))

# Mirrors: all information in sigle lines
op <- options()
options(width=300)

# Connection: write
sink(s_mirrors_tmp)
  write.table(s_mirrors,
              row.names=FALSE,
              col.names=FALSE,
              sep='|')
sink()
options(op)

# Objects: remove
rm(s_mirrors_tmp,
   s_mirrors,
   op)