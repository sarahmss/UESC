#------------------------------------------------------------------------
# This script will generate a text file with the example of an R object.
# Subsequently, the file will be opened in the editor to see the content
# and interactive learning.
#------------------------------------------------------------------------
#.. Please, do not change if you do not know what you're doing!
# J.C.Faria - Tinn-R Team
# 01/06/2021 21:33:42
#------------------------------------------------------------------------

writeLines(example(%topic,
                   give.lines=TRUE,
                   package=NULL),
           '%file')
