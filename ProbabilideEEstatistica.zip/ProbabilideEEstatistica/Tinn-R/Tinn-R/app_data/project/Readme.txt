This folder stores:All files related to project demo of Tinn-R.It is user customizable!
