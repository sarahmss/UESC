#===============================================================================
# Name   : R script template
# Author : Jos� Cl�udio Faria (Tinn-R Team)
# Date   : 09/05/2021 10:50:10
# Aim    : Template to R script
# URL    : https://tinn-r.org/en
# Mail   : joseclaudio.faria@gmail.com
#===============================================================================

#===============================
# example: 01
#===============================
set.seed(2013)

dad <- rnorm(x=1e3,
             mean=10,
             sd=2)


