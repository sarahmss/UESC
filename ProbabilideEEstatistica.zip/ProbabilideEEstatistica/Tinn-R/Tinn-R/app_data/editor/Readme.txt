This folder stores the files:Editor.ini and Editor.kst.Notice: the latest is always deleted when Tinn-R starts and recreated (storing the user preferences) when the application finishes.
