This main folder stores the folders:app, bkp, colors, data, editor, latex, project, syntax and syntax_bkp.
