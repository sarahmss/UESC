This folder stores:Dark, Default, Gray and LGray folders, each contain the ini files (All.ini, Assembly x86.ini, ..., XML.ini).
