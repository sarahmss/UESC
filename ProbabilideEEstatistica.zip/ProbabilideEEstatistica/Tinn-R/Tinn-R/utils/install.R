#------------------------------------------------------------------------
# This script will install all dependencies and
# the necessary TinnRcom package.
#------------------------------------------------------------------------
#.. Please, do not change if you do not know what you're doing!
# J.C.Faria - Tinn-R Team
# 01/06/2021 20:02:39
#------------------------------------------------------------------------

# By default it will install/update only binary packages
options(pkgType='win.binary')

# Workdir: stores
s_wd_old <- getwd()

# The 'path' will be set by Tinn-R according to its structure
setwd('%path')

# Packages: detaching (if loaded)
try(detach('package:TinnRcom'),
    silent=TRUE)

try(detach('package:formatR'),
    silent=TRUE)

try(detach('package:svMisc'),
    silent=TRUE)

try(detach('package:svSocket'),
    silent=TRUE)

# Packages: necessary
s_packs <- c('formatR_1.11.zip',
             'svMisc_1.1.4.zip',
             'svSocket_1.0.2.zip',
             'TinnRcom_1.0.22.zip')

# Packages: install
install.packages(s_packs,
                 repos=NULL,
                 type='win.binary',
                 lib=.libPaths()[1L])

# Workdir: restores
setwd(s_wd_old)

# Remove not more necessary objets
rm(s_wd_old,
   s_packs)
