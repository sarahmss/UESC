#------------------------------------------------------------------------
# This script will install all dependencies and
# the necessary TinnRcom package.
#------------------------------------------------------------------------
# Please, do not change if you do not know what you're doing!
# J.C.Faria - Tinn-R Team
# 06/03/2016 20:33:42
#------------------------------------------------------------------------
pb <- winProgressBar('Tinn-R: installing necessary R packages',
                     'Please, wait!',
                     min=0,
                     max=4,
                     initial=0)
Sys.sleep(1)

old_wd <- getwd()
setwd('%path')

# Necess�rio proteger este bloco para os casos
# em que algun pacote n�o estiver carregado.
if (grep('package:TinnRcom',
         search(),
         value=TRUE) != '')
  detach('package:TinnRcom')

if (grep('package:formatR',
         search(),
         value=TRUE) != '')
  detach('package:formatR')

if (grep('package:svMisc',
         search(),
         value=TRUE) != '')
  detach('package:svMisc')

if (grep('package:svSocket',
         search(),
         value=TRUE) != '')
  detach('package:svSocket')


pkgs <- c('formatR_1.4.zip',
          'svMisc_0.9-70.zip',
          'svSocket_0.9-57.zip',
          'TinnRcom_1.0.19.zip')

for (i in 1:length(pkgs)) {
  setWinProgressBar(pb,
                    label=pkgs[i],
                    i)

  install.packages(pkgs[i],
                   repos=NULL,
                   type='win.binary',
                   lib=.libPaths()[1L])
}

close(pb)

setwd(old_wd)
