%% Calcular campo magnético líquido produzido por um estator trifásico
bmax = 1;
freq = 60;
w = 2 * pi * freq;

% Campos magnéticos componentes
t = 0:1/6000:1/60;
Baa = bmax * sin(w * t) .* (cos(0) + 1i * sin(0));
Bbb = bmax * sin(w * t - 2*pi/3) .* (cos(2*pi/3) + 1i * sin(2*pi/3));
Bcc = bmax * sin(w * t + 2*pi/3) .* (cos(-2*pi/3) + 1i * sin(-2*pi/3));

% Cálculo de B líquida
Bnet = Baa + Bbb + Bcc;
circle = 1.5 * (cos(w * t) + 1i * sin(w * t));

% Inicializa a figura
figure;
hold on;
hBaa = plot([0, 0], [0, 0], 'k', 'LineWidth', 2);
hBbb = plot([0, 0], [0, 0], 'b', 'LineWidth', 2);
hBcc = plot([0, 0], [0, 0], 'm', 'LineWidth', 2);
hBnet = plot([0, 0], [0, 0], 'r', 'LineWidth', 3);
hCircle = plot(0, 0, 'k.');

% Adiciona legendas
legend([hBaa, hBbb, hBcc, hBnet], {'Baa', 'Bbb', 'Bcc', 'B líquida'});

% Configuração dos eixos
axis([-2 2 -2 2]);
axis square;
xlabel('Parte Real');
ylabel('Parte Imaginária');

% Animação contínua
while true
    for ii = 1:length(t)
        % Atualiza os vetores dos campos magnéticos
        set(hBaa, 'XData', [0 real(Baa(ii))], 'YData', [0 imag(Baa(ii))]);
        set(hBbb, 'XData', [0 real(Bbb(ii))], 'YData', [0 imag(Bbb(ii))]);
        set(hBcc, 'XData', [0 real(Bcc(ii))], 'YData', [0 imag(Bcc(ii))]);
        set(hBnet, 'XData', [0 real(Bnet(ii))], 'YData', [0 imag(Bnet(ii))]);

        % Atualiza o círculo de referência
        set(hCircle, 'XData', real(circle(ii)), 'YData', imag(circle(ii)));

        % Atualiza o gráfico
        drawnow;
    end
end
