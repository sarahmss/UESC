path = "./6_dados_encoder_roda_direita.csv";
[numeros, texto, raw] = xlsread(path);
disp('Primeira coluna da planilha:');
disp(numeros);