function [y] = MS7P1(x);
% MS7P1.m: MATLAB seção 7, Programa 1
% Arquivo.m de função para calcular a função sinc, y = sen(x)/x
y = ones(size(x)); i = find(x~=0);
y(i) = sin(x(i))./x(i);
