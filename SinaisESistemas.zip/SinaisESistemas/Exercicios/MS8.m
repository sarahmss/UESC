% M8_1
% Considerando 50 pontos de uma senóide de 10 Hz amostrada 
% a fs= 50Hz e escalonada por T = 1/fs
T = 1/50; N_0 = 50; n = (0:N_0-1);
% Vetor contendo exatamente 10 ciclos da senoide
x = T*cos(2*pi*10*n*T);
% Calcular TDF que é tanto discreta commo periodica
X = fft(x);
f = (0:N_0-1)/(T*N_0);
stem(f,abs(X),'k'); axis([0 50 -.05 0.55]);
% aqui tem o alias em 40Hz
stem(f-1/(T*2),fftshift(abs(X)),'k'); axis([-25 25 -0.5 0.55]);
xlabel('f [Hz]'); ylabel('|X(f)|');
stem(f-1/(T*2),fftshift(angle(X)),'k'); axis([-25 25 -1.1*pi 1.1*pi]);
xlabel('f [Hz]'); ylabel('\angle X(f)');

% M8_2
T = 1/50; N_0 = 50; n = (0:N_0-1);
y = T*exp(j*2*pi*(10+1/3)*n*T); Y = fft(y);
f = (0:N_0-1)/(T*N_0);
stem(f-25,fftshift(abs(Y)),'k'); axis([-25 25 -0.05 1.05]);
xlabel('f [Hz]'); ylabel('|Y(f)|');

% não da pra pegar o 10 + 1/3 Hz, y[n] não é real, a TDF não é 
% conjugada simétrica do sinal, vamos preencher com 11x do tamanho
% de y com 0's

%%{
y_pn = [y, zeros(1,11*length(y))]; Y_pn = fft(y_pn);
f_pn = (0:12*N_0-1)/(T*12*N_0);
stem(f_pn-25,fftshift(abs(Y_pn)),'k.'); axis([-25 25 -0.05 1.05]);
xlabel('f [Hz]'); ylabel('|Y_{pn}(f)|');
%}

% M8_3
%%{
x = (-10:.0001:10);
xsq = quantizar(x,10,3,'sym');
plot(x,xsq,'k'); grid;
xlabel('Entrada do quantizador'); ylabel('Saída do quantizador');
%}

T = 1/50; N_0 = 50; n = (0:N_0-1);
f = (0:N_0-1)/(T*N_0);
x = cos(2*pi*n*T); X = fft(x);
xaq = quantizar(x,1,3,'asym'); Xaq = fft(xaq);

subplot(2,2,1); stem(n,x,'k'); axis([0 49 -1.1 1.1]);
xlabel('n'); ylabel('x[n]');

subplot(2,2,2); stem(f-25,fftshift(abs(X)),'k'); axis([-25 25 -1 26]);
xlabel('f'); ylabel('|X(f)|');

subplot(2,2,3); stem(n,xaq,'k'); axis([0 49 -1.1 1.1]);
xlabel('n'); ylabel('x_{aq}[n]');

subplot(2,2,4); stem(f-25,fftshift(abs(Xaq)),'k'); axis([-25 25 -1 26]);
xlabel('f'); ylabel('|X_{aq}(f)|');