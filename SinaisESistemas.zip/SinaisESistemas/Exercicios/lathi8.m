A=1;
w0=1*pi;
t=0:0.5:2;
a=2;

rect = A*square(w0*t);
tri = abs(A*sawtooth(w0*(t-1), 1));

%plot(rect);
plot(t, tri);
xlabel('t[s]');
ylabel('x(t)')
