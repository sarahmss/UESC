/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bisseccao.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: coder <coder@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/14 00:34:53 by coder             #+#    #+#             */
/*   Updated: 2022/09/14 01:41:06 by coder            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifndef BISSECCAO_H
# define BISSECCAO_H

#include    <stdio.h>
#include    <stdbool.h>
#include    <math.h>
#include    <stdlib.h>
#include    <string.h>

# define log10(x) log(x)/log(10);

#endif